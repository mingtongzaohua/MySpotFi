/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: removePhsSlope_initialize.c
 *
 * MATLAB Coder version            : 4.1
 * C/C++ source code generated on  : 09-Oct-2018 10:54:42
 */

/* Include Files */
#include "removePhsSlope.h"
#include "removePhsSlope_initialize.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void removePhsSlope_initialize(void)
{
}

/*
 * File trailer for removePhsSlope_initialize.c
 *
 * [EOF]
 */
