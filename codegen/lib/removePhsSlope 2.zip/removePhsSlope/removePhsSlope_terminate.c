/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: removePhsSlope_terminate.c
 *
 * MATLAB Coder version            : 4.1
 * C/C++ source code generated on  : 09-Oct-2018 10:54:42
 */

/* Include Files */
#include "removePhsSlope.h"
#include "removePhsSlope_terminate.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void removePhsSlope_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for removePhsSlope_terminate.c
 *
 * [EOF]
 */
