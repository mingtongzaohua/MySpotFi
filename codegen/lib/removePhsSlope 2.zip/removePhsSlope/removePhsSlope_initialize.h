/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: removePhsSlope_initialize.h
 *
 * MATLAB Coder version            : 4.1
 * C/C++ source code generated on  : 09-Oct-2018 10:54:42
 */

#ifndef REMOVEPHSSLOPE_INITIALIZE_H
#define REMOVEPHSSLOPE_INITIALIZE_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "removePhsSlope_types.h"

/* Function Declarations */
extern void removePhsSlope_initialize(void);

#endif

/*
 * File trailer for removePhsSlope_initialize.h
 *
 * [EOF]
 */
