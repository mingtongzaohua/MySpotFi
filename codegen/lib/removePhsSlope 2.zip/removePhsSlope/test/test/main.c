//
//  main.c
//  test
//
//  Created by 张昊 on 2018/10/9.
//  Copyright © 2018年 张昊. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    // insert code here...
    printf("Hello, World!\n");
    return 0;
}
